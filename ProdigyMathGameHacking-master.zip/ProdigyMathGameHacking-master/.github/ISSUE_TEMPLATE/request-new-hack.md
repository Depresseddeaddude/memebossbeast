---
name: Request New Hack
about: Request a new hack!
title: "[HR]"
labels: 'enhancement,hack'
assignees: ''

---

**Describe the hack in 5 words or less:**
<!-- Example: Membership Hack-->

**(Optional) Additional information**

**Have you made sure this hack isn't available yet?* (Yes/No)**

//> No monster battle hack
//>> Allows you to walk past monsters and not start battles.
_.constants.constants["GameConstants.Debug.SCALE_ENCOUNTER_DISTANCE"] = 0;

//> Flash text hack
//>> Flash the given text across the screen.
_.instance.prodigy.effects.flashText("Text here");

//Replace Text here with the wanted text, do not remove the quotes.

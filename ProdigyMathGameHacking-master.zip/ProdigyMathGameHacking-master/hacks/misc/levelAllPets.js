//> Pet Level 100
//>> Sets all your pets to level 100.
_.player.kennel.data.map(x => x.level = 100);

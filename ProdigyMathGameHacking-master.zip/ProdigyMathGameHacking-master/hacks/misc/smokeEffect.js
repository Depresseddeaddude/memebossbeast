// Adds morph marble effect.
//>> Click on your player or travel somewhere to see the morph marble smoke effect.
_.player.transformID = 1;

//> Screen shake hack
//>> Shakes the screen VERY hard
setInterval(_ => _.instance.prodigy.effects.shake("", 100, 100))

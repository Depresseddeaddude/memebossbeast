//> Free catches hack
//>> Makes your catch cost 0.
_.constants.constants["GameConstants.Battle.CATCH_COST"] = 0;

//> Instant win hack
//>> Instantly beats any monster
Object.fromEntries(_.instance.game.state.states).Battle.startVictory();

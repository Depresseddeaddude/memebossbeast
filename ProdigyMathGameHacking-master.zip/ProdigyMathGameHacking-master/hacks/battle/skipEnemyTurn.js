//> Skip enemy turn
//>> Skips the enemy's turn. Always.
_.constants.constants["GameConstants.Battle.SKIP_ENEMY_TURN"] = true;

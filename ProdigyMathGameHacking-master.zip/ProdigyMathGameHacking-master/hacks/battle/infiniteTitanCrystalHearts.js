// You are invincible when you fight together in a titan battle.
//>> Gives you Infinite Crystal Hearts. (Client-Side only but you gain Infinite hearts and cannot lose.)

_.constants.constants ["GameConstants.CO_OP_TITAN.CRYSTAL_HP"] = Infinity;

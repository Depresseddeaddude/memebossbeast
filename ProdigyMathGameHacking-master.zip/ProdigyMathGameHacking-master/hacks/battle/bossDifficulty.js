//> Easy battles
//>> Changes boss difficulty to 0 / makes easier ~ credits sailknight ~ found by gothboymike    
_.constants.constants["GameConstants." + "ReplaceWithBossName" + ".DIFFICULTY"] = 0;
// boss list:
// Pippet
// FrostyStorm
// Gerald
// Grandoff
// IceWyrm1
// IceWyrm2
// Mira
// OldOne
// RainyStorm
// SandyStorm
// ShadowGerald
// StormyStorm
// Cebollini

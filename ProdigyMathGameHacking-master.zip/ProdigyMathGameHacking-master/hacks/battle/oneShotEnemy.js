//> One shot hack
//>> One shots your enemy
_.constants.constants["GameConstants.Battle.ATTACK_DAMAGE_OVERRIDE"] = Infinity;

//> Escape battle hack
//>> Allows player to escape battles.
try{
_.functions.escapeBattle();
} catch {
console.log('Enter a battle to escape a battle!')
}

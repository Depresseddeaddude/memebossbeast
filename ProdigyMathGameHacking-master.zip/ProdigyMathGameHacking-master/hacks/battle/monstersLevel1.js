//> Level 1 monster hack
//>> Makes all the monsters that you're battling level 1 
_.instance.prodigy.battle.constructor.MOD_DEFAULTS.level = 1;

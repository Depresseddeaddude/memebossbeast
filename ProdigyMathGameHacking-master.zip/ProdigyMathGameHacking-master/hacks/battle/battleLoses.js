//> Battle loses hack
//>> Change your arena/player battle losses to 0
_.player.data.loss = 0;

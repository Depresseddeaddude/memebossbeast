//> Chat Phrase Maker
//>> A custom chat hack. Only client side.

// NOTE: This hack is archived and no longer works.

_.instance.prodigy.gameContainer.get("ChatManager").Y.push("INSERT TEXT HERE");

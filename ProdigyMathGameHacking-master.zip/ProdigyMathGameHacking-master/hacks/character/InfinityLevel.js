//> Level infinity hack
//>> Sets your level to Infinity (Client side only).
_.player.getLevel = () => _.player.data.level = Infinity;

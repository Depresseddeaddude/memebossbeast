//> Reset account script
//>> Resets your account.
_.player.resetAccount();

//> Random wizard name
//>> Randomizes your name.
_.player.name.generateRandomName();

//> Custom name hack
//>> Gives you a custom name. Client-side only.
_.player.getName = () => "TEXT HERE";

//> Apprentice hack
//>> Sets your name to "Apprentice"
_.player.name.data.lastName = _.player.name.data.firstName = null;

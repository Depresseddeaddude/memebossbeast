export makeDiv: _ => document.createElement("div"),
export makeButton: _ => document.createElement("button"),
export make: name => document.createElement(name)
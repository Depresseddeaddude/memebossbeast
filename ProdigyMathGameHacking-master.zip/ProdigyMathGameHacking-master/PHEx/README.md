# Prodigy Hacking Extension (PHEx)

Combined with [P-NP](https://github.com/Prodigy-Hacking/P-NP) to inject modified game files into Prodigy.

Made of the Redirector extension, no-csp, and a little extra spice ;)

## [Usage](https://github.com/Prodigy-Hacking/ProdigyMathGameHacking/wiki/How-to-install-hacks)

## Building

```cmd
npm run build
```

## Credit

Originally created by [Rus](github.com/UntrustableRus/)

Maintained by the PMGH organization.

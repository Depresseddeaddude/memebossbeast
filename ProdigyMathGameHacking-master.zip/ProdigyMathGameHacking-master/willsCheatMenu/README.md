# Will's Cheat Menu

<hr>

This is the main cheat menu UI for ProdigyMathGameHacking.
Originally made by [MelnDev](https://github.com/MelnDev), now maintained by [ArcerionDev](https://github.com/ArcerionDev) and [PatheticMustan](https://github.com/PatheticMustan).

<hr>

Usage: Install the hacks, the dropdown should appear in the top left corner after a moment.

Build / Development: Install dependencies and run `webpack` in the command prompt to compile it.

```
npm i
npm run build
```

We are always looking for new contributors to help maintain the hacks and menu!

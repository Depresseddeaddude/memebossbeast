[ProdigyMathGameHackingTypings](README.md) › [Globals](globals.md)

# ProdigyMathGameHackingTypings

## Index

### Modules

* ["game.d"](modules/_game_d_.md)
* ["item.d"](modules/_item_d_.md)
* ["pixi.d"](modules/_pixi_d_.md)
* ["player.d"](modules/_player_d_.md)
* ["prodigy.d"](modules/_prodigy_d_.md)
* ["test"](modules/_test_.md)
* ["util.d"](modules/_util_d_.md)

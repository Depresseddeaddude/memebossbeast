[ProdigyMathGameHackingTypings](../README.md) › [Globals](../globals.md) › ["pixi.d"](_pixi_d_.md)

# Module: "pixi.d"

## Index

### Namespaces

* [__global](_pixi_d_.md#__global)

### Interfaces

* [PIXI](../interfaces/_pixi_d_.pixi.md)

## Namespaces

###  __global

• **__global**:

### `Const` PIXI

• **PIXI**: *[PIXI](../interfaces/_pixi_d_.pixi.md)*

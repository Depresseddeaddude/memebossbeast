# To make a public video on our hacks, please copy the format below

```text
Hacks belong to and were developed by the Prodigy-Hacking organization - https://github.com/Prodigy-Hacking/ProdigyMathGameHacking
PMGH Discord - https://discord.gg/XQDfbfq
PMGH Website - https://prodigyhacking.com
```

*If you'd like an exception, please contact us [on Discord](https://discord.gg/XQDfbfq). We're friendly, I promise!*
	

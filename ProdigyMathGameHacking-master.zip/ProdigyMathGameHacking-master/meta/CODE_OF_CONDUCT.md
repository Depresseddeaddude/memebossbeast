# Citizen Code of Conduct

Our goal was to improve Prodigy's security, not ruining the game for profit. We won't sell our hacks, or put ads.

Our hacks will **always** be open-source, and free to use.

---

You may ***never***:

- sell our hacks in any way shape or form
- hide our hacks behind a paywall/subscribewall of any kind
  - This includes adfly 😐
- use our hacks to leak private information
- use our hacks to steal user login information or tokens
- claim ownership of our hacks (Just stop bragging about it 😠)
- modify it slightly just to add your own ads 🤨

If you're gonna talk about our hacks (on YouTube or other social media platforms), please please pretty please [credit us properly](https://github.com/Prodigy-Hacking/ProdigyMathGameHacking/blob/master/YOUTUBE_ATTRIBUTION.md).

It hurts our souls when skids take credit for our hacks and don't even link us.

---

Last reminder that we are **volunteers**, and do not profit from this. We do this for *fun*, not for evil. Please don't spoil our fun.
